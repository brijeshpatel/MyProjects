#include<QFile>
#include<QTreeView>
#include<QList>
#include<QtCore>
#include<QtGui>
#include<QProcess>
#include<QStandardItemModel>
#include "mainwindow.h"
#include<polkit-qt-1/polkitqt1-gui-action.h>
#include<polkit-qt-1/polkitqt1-gui-actionbutton.h>
#include<polkit-qt-1/polkitqt1-authority.h>
using namespace PolkitQt1::Gui;
using namespace PolkitQt1;

MainWindow::MainWindow(QWidget *parent):QMainWindow(parent)
{
	setupUi(this);
	model = new QStandardItemModel(0,3);
        model->setHorizontalHeaderItem( 0, new QStandardItem( "Network" ) );
        model->setHorizontalHeaderItem( 1, new QStandardItem( "Type" ) );
	model->setHorizontalHeaderItem( 2, new QStandardItem( "Strength" ) );
//	QList<QStandardItem*> row;
//        row.append(new QStandardItem("Brijesh"));
//        row.append(new QStandardItem("Ad-Hoc"));
//        row.append(new QStandardItem("20/70"));
//        qDebug() << row;
//        model->appendRow(row);

	treeView->setModel( model );
	refreshList();  
        Action *bt = new Action("org.freedesktop.wmanager.connect",this);
        /*act->setVisible(true,Action::Auth);
        act->setEnabled(true,Action::Auth);
        act->setText("Kick... (long)", Action::Auth);
        connect(actionRefresh, SIGNAL(triggered()), act, SLOT(activate()));
        connect(act, SIGNAL(authorized()), this, SLOT(actionRefreshTriggered()));*/

       // QPushButton *b = new QPushButton("Auth",this);
       // ActionButton *bt = new ActionButton(b,"org.freedesktop.wmanager.connect",this);
        /*bt->setVisible(true, Action::No);
        bt->setEnabled(true, Action::No);
        bt->setText("Kick (long)", Action::No);
        bt->setToolTip("If your admin wasn't annoying, you could do this", Action::No);
        // here we set the behavior of PolKitResul = Auth
        bt->setVisible(true, Action::Auth);
        bt->setEnabled(true, Action::Auth);
        bt->setText("Kick... (long)", Action::Auth);
        //bt->setIcon(QPixmap(":/Icons/action-locked-default.png"), Action::Auth);
        bt->setToolTip("Only card carrying tweakers can do this!", Action::Auth);
        // here we set the behavior of PolKitResul = Yes
        bt->setVisible(true, Action::Yes);
        bt->setEnabled(true, Action::Yes);
        bt->setText("Kick! (long)", Action::Yes);
        //bt->setIcon(QPixmap(":/Icons/custom-yes.png"), Action::Yes);
        bt->setToolTip("Go ahead, kick kick kick!", Action::Yes);*/
        connect(treeView,SIGNAL(doubleClicked(const QModelIndex &)),bt,SLOT(activate()));
        connect(actionConnect, SIGNAL(triggered()), bt, SLOT(activate()));
        connect(actionRefresh,SIGNAL(triggered()),this,SLOT(actionRefreshTriggered()));
        connect(actionQuit,SIGNAL(triggered()),qApp,SLOT(quit()));
        connect(bt, SIGNAL(authorized()), this, SLOT(actionConnectTriggered()));



}

void MainWindow::actionRefreshTriggered()
{
        qDebug()<<"Reloading list.....";
	refreshList();
}
void MainWindow::actionConnectTriggered()
{
        QModelIndexList li=treeView->selectionModel()->selectedIndexes();
	int r=li.at(0).row();
        connectTo(list.at(r));

}
void MainWindow::refreshList()
{
	list.clear();
	model->clear();
	QProcess scanP;
	scanP.start("iwlist",QStringList() << "wlan0" << "scan");
	QByteArray output;
        while(scanP.waitForFinished()){
        }
	output=scanP.readAll();
	QStringList strList = QString(output).split('\n');
	QString interface="";
	CellInfo cell;	
	for(int i=0; i<strList.size(); i++)
	{
                QStringList tokens = strList.at(i).split(' ',QString::SkipEmptyParts);
		qDebug() << tokens;
		if(tokens.size()==0) continue;
		if(tokens.size()==1)
		{
			if(tokens.at(0).contains("ESSID:"))
			{
				cell.essid=tokens.at(0).split(':').at(1).split('"',QString::SkipEmptyParts).at(0);
			}
			if(tokens.at(0).contains("Mode:"))
			{
				cell.mode=tokens.at(0).split(':').at(1);
                                if(cell.mode=="Master"){cell.mode="Managed";}
				list << cell;
				QList<QStandardItem*> row;
				row.append(new QStandardItem(cell.essid));
				row.append(new QStandardItem(cell.mode));
				row.append(new QStandardItem(cell.quality));
                                qDebug() <<"Added:"<< row ;
				model->appendRow(row);			
			}
			if(tokens.at(0).contains("Channel:"))
			{
				cell.channel=tokens.at(0).split(':').at(1);
			}
			continue;
		}
		if(tokens.size()==2)
		{
			if(tokens.at(0).contains("Encryption"))
			{
				cell.encryption=tokens.at(1).split(':').at(1);
			}
			continue;
		}
		if(tokens.size()>=3)
		{
			if(tokens.at(1)=="Scan" && tokens.at(2)=="completed")
			{
				interface = tokens.at(0);
				continue;
			}
			if(tokens.at(0)=="Cell" && tokens.at(3)=="Address:")
			{
				cell.address=tokens.at(4);
				cell.interface=interface;
				continue;
			}
			if(tokens.at(0).contains("Quality="))
			{
				cell.quality=tokens.at(0).split('=').at(1);
				continue;
			}
			
		}
	}
		
}
void MainWindow::connectTo(CellInfo cell)
{
//	strsetenv("interface", cell.interface);
//	strsetenv("address", cell.address);
//   	strsetenv("essid", cell.essid);
//   	strsetenv("mode", cell.mode);
  //  Authority::Result result;
  //  UnixProcessSubject subject(static_cast<uint>(QCoreApplication::applicationPid()));
//    result = Authority::instance()->checkAuthorizationSync("org.freedesktop.wmanager.connect",subject,Authority::AllowUserInteraction);
//    if(result==Authority::Yes)
//    {
        QProcess scanP;
        scanP.start("echo",QStringList()<<"Connecting....");

        scanP.readAll();
        Authority::Result result;
        UnixProcessSubject subject(static_cast<uint>(QCoreApplication::applicationPid()));
        result = Authority::instance()->checkAuthorizationSync("org.freedesktop.wmanager.connect",subject,Authority::AllowUserInteraction);
        QString password="hylex";
        system(QString("echo "+password+" | sudo -S echo authorized").toLocal8Bit());
        QByteArray output;

        scanP.write(QByteArray("hylex"));
        scanP.write(QByteArray(QString('\n').toLocal8Bit()));
        scanP.execute("sudo",QStringList()<<"echo"<<"brijesh");
        scanP.execute("./connect", QStringList() << cell.interface << cell.address << cell.essid << cell.mode);
        while(scanP.waitForFinished()){
        }
        output=scanP.readAll();
//    }
 //   else
//    {
 //       qDebug()<<"Require root privileges to connect....:(";
 //   }


}
