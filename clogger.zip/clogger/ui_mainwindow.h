/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Sun Dec 11 00:31:13 2011
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *userHLayout;
    QLabel *userL;
    QLineEdit *user;
    QHBoxLayout *passHLayout;
    QLabel *passL;
    QLineEdit *password;
    QHBoxLayout *footHLayout;
    QCheckBox *rememberMe;
    QPushButton *loginButton;

    void setupUi(QWidget *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(212, 106);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(212, 106));
        MainWindow->setMaximumSize(QSize(212, 106));
        MainWindow->setMouseTracking(false);
        MainWindow->setWindowOpacity(0.91);
        layoutWidget = new QWidget(MainWindow);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 192, 83));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        userHLayout = new QHBoxLayout();
        userHLayout->setObjectName(QString::fromUtf8("userHLayout"));
        userL = new QLabel(layoutWidget);
        userL->setObjectName(QString::fromUtf8("userL"));

        userHLayout->addWidget(userL);

        user = new QLineEdit(layoutWidget);
        user->setObjectName(QString::fromUtf8("user"));

        userHLayout->addWidget(user);


        verticalLayout->addLayout(userHLayout);

        passHLayout = new QHBoxLayout();
        passHLayout->setObjectName(QString::fromUtf8("passHLayout"));
        passL = new QLabel(layoutWidget);
        passL->setObjectName(QString::fromUtf8("passL"));

        passHLayout->addWidget(passL);

        password = new QLineEdit(layoutWidget);
        password->setObjectName(QString::fromUtf8("password"));
        password->setInputMethodHints(Qt::ImhHiddenText|Qt::ImhNoAutoUppercase|Qt::ImhNoPredictiveText);
        password->setEchoMode(QLineEdit::Password);

        passHLayout->addWidget(password);


        verticalLayout->addLayout(passHLayout);

        footHLayout = new QHBoxLayout();
        footHLayout->setObjectName(QString::fromUtf8("footHLayout"));
        rememberMe = new QCheckBox(layoutWidget);
        rememberMe->setObjectName(QString::fromUtf8("rememberMe"));

        footHLayout->addWidget(rememberMe);

        loginButton = new QPushButton(layoutWidget);
        loginButton->setObjectName(QString::fromUtf8("loginButton"));

        footHLayout->addWidget(loginButton);


        verticalLayout->addLayout(footHLayout);


        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QWidget *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Form", 0, QApplication::UnicodeUTF8));
        userL->setText(QApplication::translate("MainWindow", "Username  :", 0, QApplication::UnicodeUTF8));
        passL->setText(QApplication::translate("MainWindow", "Password   :", 0, QApplication::UnicodeUTF8));
        rememberMe->setText(QApplication::translate("MainWindow", "Remember Me", 0, QApplication::UnicodeUTF8));
        loginButton->setText(QApplication::translate("MainWindow", "Login", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
